# AI Hub WordPress Plugin

## Purpose

This plugin bridges the AI Hub automation layer with tenant WordPress sites that use Bricks Builder. It exposes authenticated REST endpoints that allow the hub to fetch and update page layouts, while keeping audit trails and manual approval loops intact.

## Installation

1. Copy the `ai-hub-plugin` folder into your WordPress `wp-content/plugins/` directory.
2. Activate **AI Hub Connector** from the WordPress plugins screen.
3. Navigate to **Settings → AI Hub**:
   - Enter the AI Hub base URL for your environment.
   - Paste the tenant automation API key generated in the AI Hub superadmin.
   - Paste the automation token generated in the AI Hub admin, *or*
   - Click **Generate new token**, copy the value immediately, and paste it back into the AI Hub admin UI so the platform stores the encrypted copy.

The settings page shows a short token hint and rotation timestamp for validation. Tokens are stored in plain form (for outbound calls) plus a SHA256 hash used to validate inbound requests from the hub.

## REST Endpoints

All endpoints require the `X-AI-Hub-Token` header. Tokens that do not match the stored hash return `401`.

| Method | Route                              | Description                                |
| ------ | ---------------------------------- | ------------------------------------------ |
| GET    | `/wp-json/ai-hub/v1/bricks/{id}`   | Returns the current Bricks JSON + metadata |
| POST   | `/wp-json/ai-hub/v1/bricks/{id}`   | Replaces layout/settings/preview JSON      |

Successful updates fire `bricks_after_save_post` and `bricks/post_updated`, ensuring Bricks caches rebuild and downstream hooks run.

## Development Notes

- PHP 8.2+ and WordPress 6.5+ are required. Guard clauses block direct access (`if (! defined('ABSPATH')) { exit; }`).
- Layout JSON is validated before saving. Invalid JSON yields `400`.
- Meta keys updated: `_bricks_page_content` (or `_bricks_page_content_2` fallback), `_bricks_page_settings`, `_bricks_page_preview`.
- Previous meta snapshots are returned in the POST response so the hub can diff and audit changes.
- Hub requests must now include two headers: `X-AI-Hub-Token` (site automation token) and `X-AI-Hub-Tenant-Key` (tenant automation key). The plugin validates both against the stored configuration.

## Testing

```bash
find wordpress-plugin/ai-hub-plugin -name '*.php' -print0 | xargs -0 -n1 php -l
```

For manual checks, call the REST endpoint with curl:

```bash
curl -H "X-AI-Hub-Token: $AI_HUB_TOKEN" https://example.com/wp-json/ai-hub/v1/bricks/123
```

Expect JSON describing the current post layout, or a 401/404 on invalid token/post IDs.
