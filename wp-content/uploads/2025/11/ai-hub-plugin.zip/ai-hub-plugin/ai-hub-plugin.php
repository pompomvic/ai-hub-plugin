<?php
/**
 * Plugin Name: AI Hub Connector
 * Description: Connects AI Hub automation with Bricks Builder-powered WordPress sites.
 * Version: 0.1.0
 * Requires at least: 6.5
 * Requires PHP: 8.2
 * Author: AI Hub
 * Author URI: https://aihub.example.com
 * Text Domain: ai-hub-plugin
 *
 * @package AIHub\Plugin
 */

declare(strict_types=1);

if (! defined('ABSPATH')) {
	exit;
}

if (! defined('AI_HUB_PLUGIN_FILE')) {
	define('AI_HUB_PLUGIN_FILE', __FILE__);
}

if (! defined('AI_HUB_PLUGIN_DIR')) {
	define('AI_HUB_PLUGIN_DIR', __DIR__);
}

require_once AI_HUB_PLUGIN_DIR . '/includes/class-plugin.php';

\AIHub\Plugin\Plugin::instance();
