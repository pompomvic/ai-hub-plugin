<?php
/**
 * Handles automation token lifecycle.
 *
 * @package AIHub\Plugin
 */

declare(strict_types=1);

namespace AIHub\Plugin;

use WP_Error;
use WP_REST_Request;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Manages shared automation token storage and validation.
 */
final class Token_Manager {
	private const OPTION_TOKEN_PLAIN    = 'ai_hub_plugin_token_plain';
	private const OPTION_TOKEN_HASH     = 'ai_hub_plugin_token_hash';
	private const OPTION_TOKEN_ROTATED  = 'ai_hub_plugin_token_rotated_at';
	private const OPTION_TOKEN_HINT     = 'ai_hub_plugin_token_hint';
	private const TOKEN_HEADER          = 'x-ai-hub-token';
	private const AUTHORIZATION_HEADER  = 'authorization';

	private static ?Token_Manager $instance = null;

	private function __construct() {
	}

	/**
	 * Singleton accessor.
	 */
	public static function instance(): Token_Manager {
		if (self::$instance === null) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Ensure the provided token matches the stored hash.
	 *
	 * @throws WP_Error When token is missing or invalid.
	 */
	public function require_valid_token(string $token): void {
		if ($token === '') {
			throw new WP_Error(
				'ai_hub_missing_token',
				__('AI Hub token header required.', 'ai-hub-plugin'),
				['status' => 401]
			);
		}

		if (! $this->verify($token)) {
			throw new WP_Error(
				'ai_hub_invalid_token',
				__('Invalid AI Hub automation token.', 'ai-hub-plugin'),
				['status' => 401]
			);
		}
	}

	/**
	 * Return true when the provided token matches the stored hash.
	 */
	public function verify(string $token): bool {
		$hash = get_option(self::OPTION_TOKEN_HASH, '');
		if ($hash === '') {
			return false;
		}

		$provided = hash('sha256', $token);

		return hash_equals($hash, $provided);
	}

	/**
	 * Update the stored token hash and metadata.
	 */
	public function store_token(string $token): void {
		update_option(self::OPTION_TOKEN_PLAIN, $token, false);
		update_option(self::OPTION_TOKEN_HASH, hash('sha256', $token), false);
		update_option(self::OPTION_TOKEN_ROTATED, time(), false);
		update_option(self::OPTION_TOKEN_HINT, $this->build_token_hint($token), false);
	}

	/**
	 * Generate and persist a new token string.
	 */
	public function generate_token(): string {
		$token = wp_generate_password(64, false, false);
		$this->store_token($token);

		return $token;
	}

	/**
	 * Return the stored plain token, if any.
	 */
	public function get_token(): string {
		return (string) get_option(self::OPTION_TOKEN_PLAIN, '');
	}

	/**
	 * Extract token from REST request headers.
	 */
	public function extract_token_from_request(WP_REST_Request $request): string {
		$headers  = array_change_key_case($request->get_headers(), CASE_LOWER);
		$raw      = $headers[self::TOKEN_HEADER][0] ?? '';
		$auth     = $headers[self::AUTHORIZATION_HEADER][0] ?? '';
		$auth     = is_string($auth) ? trim($auth) : '';
		$token    = is_string($raw) ? trim($raw) : '';

		if ($token !== '') {
			return $token;
		}

		if (stripos($auth, 'Bearer ') === 0) {
			return trim(substr($auth, 7));
		}

		return '';
	}

	/**
	 * Return a short token hint for admin UI.
	 */
	public function get_token_hint(): string {
		return (string) get_option(self::OPTION_TOKEN_HINT, '');
	}

	/**
	 * Return the unix timestamp when the token last rotated.
	 */
	public function get_last_rotation(): int {
		return (int) get_option(self::OPTION_TOKEN_ROTATED, 0);
	}

	/**
	 * Remove stored token data.
	 */
	public function clear_token(): void {
		delete_option(self::OPTION_TOKEN_PLAIN);
		delete_option(self::OPTION_TOKEN_HASH);
		delete_option(self::OPTION_TOKEN_ROTATED);
		delete_option(self::OPTION_TOKEN_HINT);
	}

	private function build_token_hint(string $token): string {
		if ($token === '') {
			return '';
		}

		$prefix = substr($token, 0, 4);
		$suffix = substr($token, -4);

		return sprintf('%s…%s', $prefix, $suffix);
	}
}
