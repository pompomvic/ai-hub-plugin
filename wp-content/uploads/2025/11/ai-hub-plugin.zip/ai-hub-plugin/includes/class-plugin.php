<?php
/**
 * Main plugin bootstrap.
 *
 * @package AIHub\Plugin
 */

declare(strict_types=1);

namespace AIHub\Plugin;

use AIHub\Plugin\Admin\Settings_Page;
use AIHub\Plugin\Rest\Bricks_Controller;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Coordinates plugin hooks and shared services.
 */
final class Plugin {
	private static ?Plugin $instance = null;

	private function __construct() {
		$this->load_dependencies();

		add_action('init', [$this, 'load_textdomain']);
		add_action('rest_api_init', [$this, 'register_rest_routes']);
		add_action('admin_menu', [$this, 'register_admin_menu']);
		add_action('admin_init', [$this, 'register_settings']);
	}

	/**
	 * Return the singleton instance.
	 */
	public static function instance(): Plugin {
		if (self::$instance === null) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Include required class files.
	 */
	private function load_dependencies(): void {
		require_once __DIR__ . '/class-token-manager.php';
		require_once __DIR__ . '/rest/class-request-context.php';
		require_once __DIR__ . '/rest/class-bricks-controller.php';
		require_once __DIR__ . '/admin/class-settings-page.php';
	}

	/**
	 * Load translations.
	 */
	public function load_textdomain(): void {
		load_plugin_textdomain(
			'ai-hub-plugin',
			false,
			dirname(plugin_basename(\AI_HUB_PLUGIN_FILE)) . '/languages'
		);
	}

	/**
	 * Register REST API routes.
	 */
	public function register_rest_routes(): void {
		$token_manager = Token_Manager::instance();
		$controller    = new Bricks_Controller($token_manager);
		$controller->register_routes();
	}

	/**
	 * Add admin menu entries.
	 */
	public function register_admin_menu(): void {
		Settings_Page::instance()->register();
	}

	/**
	 * Register admin settings.
	 */
	public function register_settings(): void {
		Settings_Page::instance()->register_settings();
	}
}
