<?php
/**
 * REST controller for Bricks Builder interactions.
 *
 * @package AIHub\Plugin
 */

declare(strict_types=1);

namespace AIHub\Plugin\Rest;

use AIHub\Plugin\Token_Manager;
use AIHub\Plugin\Admin\Settings_Page;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Exposes REST endpoints consumed by the AI Hub.
 */
final class Bricks_Controller {
	private const REST_NAMESPACE = 'ai-hub/v1';

	private const META_CONTENT_PRIMARY = '_bricks_page_content';
	private const META_CONTENT_BACKUP  = '_bricks_page_content_2';
	private const META_SETTINGS        = '_bricks_page_settings';
	private const META_PREVIEW         = '_bricks_page_preview';

	private Token_Manager $tokens;

	public function __construct(Token_Manager $tokens) {
		$this->tokens = $tokens;
	}

	/**
	 * Register REST API routes.
	 */
	public function register_routes(): void {
		register_rest_route(
			self::REST_NAMESPACE,
			'/bricks/(?P<post_id>\d+)',
			[
				[
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => [$this, 'get_bricks_document'],
					'permission_callback' => [$this, 'permission_check'],
					'args'                => $this->get_common_args(),
				],
				[
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => [$this, 'update_bricks_document'],
					'permission_callback' => [$this, 'permission_check'],
					'args'                => $this->get_update_args(),
				],
			]
		);
	}

	/**
	 * Ensure automation token is valid before executing.
	 *
	 * @return bool|WP_Error
	 */
	public function permission_check(WP_REST_Request $request) {
		$context = new Request_Context($this->tokens, $request);

        try {
            $context->validate_token();
        } catch (WP_Error $error) {
            return $error;
        }

        $stored_key = (string) get_option(Settings_Page::OPTION_TENANT_API_KEY, '');
        if ($stored_key !== '') {
            $provided = (string) $request->get_header('x-ai-hub-tenant-key');
            $provided = trim($provided);
            if ($provided === '' || ! hash_equals($stored_key, $provided)) {
                return new WP_Error(
                    'ai_hub_invalid_tenant_key',
                    __('Tenant API key is missing or invalid.', 'ai-hub-plugin'),
                    ['status' => 401]
                );
            }
        }

        $request->set_attribute('ai_hub_context', $context);

        return true;
    }

	/**
	 * Fetch Bricks document for a post.
	 */
	public function get_bricks_document(WP_REST_Request $request): WP_REST_Response {
		/** @var Request_Context $context */
		$context = $request->get_attribute('ai_hub_context');
		$post    = $context->require_post();
		$post_id = $post->ID;

		$payload = [
			'post_id'            => $post_id,
			'post_title'         => $post->post_title,
			'post_type'          => $post->post_type,
			'modified_gmt'       => get_post_modified_time('c', true, $post),
			'checksum'           => $this->calculate_checksum($post_id),
			'content'            => $this->maybe_decode_meta($post_id, self::META_CONTENT_PRIMARY, self::META_CONTENT_BACKUP),
			'settings'           => $this->maybe_decode_meta($post_id, self::META_SETTINGS),
			'preview'            => $this->maybe_decode_meta($post_id, self::META_PREVIEW),
			'raw_meta'           => $this->get_raw_meta_snapshot($post_id),
			'content_meta_key'   => $this->resolve_content_meta_key($post_id),
			'meta_version'       => $this->resolve_meta_version($post_id),
			'token_hint'         => $this->tokens->get_token_hint(),
			'token_rotated_unix' => $this->tokens->get_last_rotation(),
		];

		return new WP_REST_Response($payload, 200);
	}

	/**
	 * Update Bricks document for a post.
	 */
	public function update_bricks_document(WP_REST_Request $request): WP_REST_Response {
		/** @var Request_Context $context */
		$context = $request->get_attribute('ai_hub_context');
		$post    = $context->require_post();
		$post_id = $post->ID;

		$input = $this->normalise_update_payload($request);

		$previous = $this->get_raw_meta_snapshot($post_id);

		$this->persist_meta($post_id, $input);
		$this->touch_post($post_id);
		$this->trigger_bricks_hooks($post_id, $post);

		$updated = $this->get_raw_meta_snapshot($post_id);

		$response = [
			'post_id'      => $post_id,
			'checksum'     => $this->calculate_checksum($post_id),
			'updated_meta' => $updated,
			'previous_meta'=> $previous,
			'applied_at'   => gmdate('c'),
			'mode'         => 'replace',
		];

		return new WP_REST_Response($response, 200);
	}

	/**
	 * Build args array shared across routes.
	 */
	private function get_common_args(): array {
		return [
			'post_id' => [
				'required'          => true,
				'description'       => __('Numeric post ID.', 'ai-hub-plugin'),
				'type'              => 'integer',
				'validate_callback' => static fn ($value) => is_numeric($value) && (int) $value > 0,
			],
		];
	}

	/**
	 * Build args schema for update requests.
	 */
	private function get_update_args(): array {
		return [
			'content'       => [
				'description' => __('Bricks JSON structure to replace current layout.', 'ai-hub-plugin'),
				'type'        => 'object',
				'required'    => false,
			],
			'content_raw'   => [
				'description' => __('Pre-encoded JSON string for Bricks layout.', 'ai-hub-plugin'),
				'type'        => 'string',
				'required'    => false,
			],
			'settings'      => [
				'description' => __('Bricks settings JSON structure.', 'ai-hub-plugin'),
				'type'        => 'object',
				'required'    => false,
			],
			'preview'       => [
				'description' => __('Optional preview payload.', 'ai-hub-plugin'),
				'type'        => 'object',
				'required'    => false,
			],
		];
	}

	/**
	 * Normalise update payload.
	 *
	 * @throws WP_Error If payload is invalid.
	 */
	private function normalise_update_payload(WP_REST_Request $request): array {
		$content     = $request->get_param('content');
		$content_raw = $request->get_param('content_raw');
		$settings    = $request->get_param('settings');
		$preview     = $request->get_param('preview');

		if ($content === null && $content_raw === null && $settings === null && $preview === null) {
			throw new WP_Error(
				'ai_hub_missing_payload',
				__('At least one of content, settings, or preview must be provided.', 'ai-hub-plugin'),
				['status' => 400]
			);
		}

		$normalised = [
			'content'     => $this->prepare_json_value($content, $content_raw, 'content'),
			'settings'    => $this->prepare_json_value($settings, null, 'settings'),
			'preview'     => $this->prepare_json_value($preview, null, 'preview'),
		];

		return $normalised;
	}

	/**
	 * Convert structures to JSON strings for storage.
	 *
	 * @throws WP_Error If encoding fails.
	 */
	private function prepare_json_value($structured, ?string $raw, string $field): ?string {
		if ($raw !== null) {
			$trimmed = trim((string) $raw);
			$this->assert_valid_json($trimmed, $field);

			return $trimmed;
		}

		if ($structured === null) {
			return null;
		}

		$encoded = wp_json_encode($structured, JSON_UNESCAPED_UNICODE);
		if (! is_string($encoded) || $encoded === '') {
			throw new WP_Error(
				'ai_hub_invalid_json',
				sprintf(
					/* translators: %s refers to the invalid field name. */
					__('Unable to encode %s payload as JSON.', 'ai-hub-plugin'),
					$field
				),
				['status' => 400]
			);
		}

		return $encoded;
	}

	/**
	 * Ensure string is valid JSON.
	 *
	 * @throws WP_Error If invalid JSON.
	 */
	private function assert_valid_json(string $value, string $field): void {
		json_decode($value, true);
		if (json_last_error() !== JSON_ERROR_NONE) {
			throw new WP_Error(
				'ai_hub_invalid_json',
				sprintf(
					/* translators: %s refers to the invalid field name. */
					__('Invalid JSON provided for %s.', 'ai-hub-plugin'),
					$field
				),
				['status' => 400]
			);
		}
	}

	private function resolve_content_meta_key(int $post_id): string {
		$primary = get_post_meta($post_id, self::META_CONTENT_PRIMARY, true);

		return $primary !== '' ? self::META_CONTENT_PRIMARY : self::META_CONTENT_BACKUP;
	}

	private function persist_meta(int $post_id, array $payload): void {
		$content_key = $this->resolve_content_meta_key($post_id);

		if ($payload['content'] !== null) {
			update_post_meta($post_id, $content_key, wp_slash($payload['content']));
		}

		if ($payload['settings'] !== null) {
			update_post_meta($post_id, self::META_SETTINGS, wp_slash($payload['settings']));
		}

		if ($payload['preview'] !== null) {
			update_post_meta($post_id, self::META_PREVIEW, wp_slash($payload['preview']));
		}
	}

	/**
	 * Record a post update to bump modified timestamps.
	 */
	private function touch_post(int $post_id): void {
		wp_update_post(
			[
				'ID'            => $post_id,
				'post_modified' => current_time('mysql'),
				'post_modified_gmt' => current_time('mysql', 1),
			]
		);
	}

	/**
	 * Invoke Bricks hooks for cache invalidation.
	 */
	private function trigger_bricks_hooks(int $post_id, \WP_Post $post): void {
		do_action('bricks_after_save_post', $post_id, $post);
		do_action('bricks/post_updated', $post_id, $post);
	}

	/**
	 * Decode JSON stored in post meta, gracefully handling invalid values.
	 *
	 * @return mixed|null
	 */
	private function maybe_decode_meta(int $post_id, string $primary_key, ?string $fallback_key = null) {
		$raw = get_post_meta($post_id, $primary_key, true);
		if ($raw === '' && $fallback_key !== null) {
			$raw = get_post_meta($post_id, $fallback_key, true);
		}

		if (! is_string($raw) || trim($raw) === '') {
			return null;
		}

		$decoded = json_decode($raw, true);

		return json_last_error() === JSON_ERROR_NONE ? $decoded : null;
	}

	/**
	 * Return raw meta snapshot (without decoding).
	 */
	private function get_raw_meta_snapshot(int $post_id): array {
		$keys = [
			'content_primary' => get_post_meta($post_id, self::META_CONTENT_PRIMARY, true),
			'content_backup'  => get_post_meta($post_id, self::META_CONTENT_BACKUP, true),
			'settings'        => get_post_meta($post_id, self::META_SETTINGS, true),
			'preview'         => get_post_meta($post_id, self::META_PREVIEW, true),
		];

		return array_map(
			static fn ($value) => is_string($value) ? $value : null,
			$keys
		);
	}

	/**
	 * Derive checksum from stored meta for drift detection.
	 */
	private function calculate_checksum(int $post_id): string {
		$data = $this->get_raw_meta_snapshot($post_id);

		return hash('sha256', wp_json_encode($data));
	}

	/**
	 * Determine meta version label.
	 */
	private function resolve_meta_version(int $post_id): string {
		$primary = get_post_meta($post_id, self::META_CONTENT_PRIMARY, true);

		return $primary !== '' ? 'content' : 'content_2';
	}
}
