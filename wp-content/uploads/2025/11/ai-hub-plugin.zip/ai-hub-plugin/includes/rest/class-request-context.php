<?php
/**
 * Helper for extracting common REST request data.
 *
 * @package AIHub\Plugin
 */

declare(strict_types=1);

namespace AIHub\Plugin\Rest;

use AIHub\Plugin\Token_Manager;
use WP_Error;
use WP_Post;
use WP_REST_Request;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Provides validated context for Bricks automation requests.
 */
final class Request_Context {
	private Token_Manager $tokens;
	private WP_REST_Request $request;
	private string $token;

	public function __construct(Token_Manager $tokens, WP_REST_Request $request) {
		$this->tokens  = $tokens;
		$this->request = $request;
		$this->token   = $tokens->extract_token_from_request($request);
	}

	/**
	 * Validate automation token; throws on failure.
	 *
	 * @throws WP_Error When token is missing or invalid.
	 */
	public function validate_token(): void {
		$this->tokens->require_valid_token($this->token);
	}

	/**
	 * Return post ID from request.
	 */
	public function get_post_id(): int {
		$post_id = (int) $this->request->get_param('post_id');

		if ($post_id <= 0) {
			throw new WP_Error(
				'ai_hub_invalid_post_id',
				__('Valid post ID required.', 'ai-hub-plugin'),
				['status' => 400]
			);
		}

		return $post_id;
	}

	/**
	 * Fetch the post object associated with the request.
	 *
	 * @throws WP_Error When the post is missing or access is denied.
	 */
	public function require_post(): WP_Post {
		$post_id = $this->get_post_id();
		$post    = get_post($post_id);

		if (! $post instanceof WP_Post) {
			throw new WP_Error(
				'ai_hub_post_not_found',
				__('Requested post not found.', 'ai-hub-plugin'),
				['status' => 404]
			);
		}

		return $post;
	}

	/**
	 * Return original REST request.
	 */
	public function get_request(): WP_REST_Request {
		return $this->request;
	}
}
